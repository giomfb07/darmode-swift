//
//  ViewController.swift
//  darkmode
//
//  Created by COTEMIG on 06/05/25.
//

import UIKit

var lightOn = true

class ViewController: UIViewController {

    @IBOutlet weak var labelDarkmode: UILabel!
    @IBOutlet weak var buttonDarkmode: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
    }

    @IBAction func buttonPressed(_ sender: Any) {
        print("Button pressed")
        lightOn.toggle()
        if lightOn{
           
            view.backgroundColor = .white
            buttonDarkmode.tintColor = .blue
            labelDarkmode.text = "Darkmode"
            labelDarkmode.textColor = .black

           
        }else{
            view.backgroundColor = .black
            buttonDarkmode.tintColor = .purple
            labelDarkmode.textColor = .white
            labelDarkmode.text = "Lightmode"
        }
    }
    
}

